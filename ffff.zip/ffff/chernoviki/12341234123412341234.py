s = '1123212'
for i in range(2):
    print(s[-2:])
