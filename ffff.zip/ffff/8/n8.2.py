from itertools import *
n = product('0123456789', repeat=5)
a = []
for i in n:
    a.append(list(i))


